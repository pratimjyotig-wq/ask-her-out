// ============================================================
//  ASK ME OUT — script.js
//  Vanilla JS only. No dependencies, no backend.
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ---------- Element references ----------
  const screenOne   = document.getElementById('screenOne');
  const screenTwo   = document.getElementById('screenTwo');
  const yesBtn      = document.getElementById('yesBtn');
  const noBtn       = document.getElementById('noBtn');
  const buttonRow   = document.getElementById('buttonRow');
  const floatingHeartsContainer = document.getElementById('floatingHearts');
  const confettiCanvas = document.getElementById('confettiCanvas');

  // Safety checks so a missing element never throws a hard error
  if (!screenOne || !screenTwo || !yesBtn || !noBtn) {
    console.warn('Ask-Me-Out: one or more required elements were not found.');
    return;
  }

  // Ensure the second screen is definitely hidden on load
  screenTwo.classList.add('hidden');
  screenOne.classList.remove('hidden');

  // ============================================================
  // 1. FLOATING HEARTS BACKGROUND
  // ============================================================
  const heartEmojis = ['💗', '💕', '💖', '💘', '💞', '❤️', '🩷'];

  function createFloatingHeart() {
    if (!floatingHeartsContainer) return;

    const heart = document.createElement('span');
    heart.className = 'floating-heart';
    heart.textContent = heartEmojis[Math.floor(Math.random() * heartEmojis.length)];

    const startLeft = Math.random() * 100; // vw
    const duration = 6 + Math.random() * 6; // 6s - 12s
    const size = 14 + Math.random() * 18; // 14px - 32px
    const delay = Math.random() * 2;

    heart.style.left = startLeft + 'vw';
    heart.style.fontSize = size + 'px';
    heart.style.animationDuration = duration + 's';
    heart.style.animationDelay = delay + 's';

    floatingHeartsContainer.appendChild(heart);

    // Clean up after the animation finishes so the DOM doesn't grow forever
    setTimeout(() => {
      heart.remove();
    }, (duration + delay) * 1000 + 500);
  }

  // Seed some hearts immediately, then keep spawning
  for (let i = 0; i < 10; i++) {
    setTimeout(createFloatingHeart, i * 300);
  }
  const heartInterval = setInterval(createFloatingHeart, 700);

  // ============================================================
  // 2. "NO" BUTTON — DODGES THE CURSOR / TAP
  // ============================================================
  let dodgeCount = 0;

  function getSafeRandomPosition() {
    const margin = 16;
    const btnWidth = noBtn.offsetWidth || 120;
    const btnHeight = noBtn.offsetHeight || 50;

    const maxLeft = window.innerWidth - btnWidth - margin;
    const maxTop = window.innerHeight - btnHeight - margin;

    const randomLeft = Math.max(margin, Math.random() * maxLeft);
    const randomTop = Math.max(margin, Math.random() * maxTop);

    return { left: randomLeft, top: randomTop };
  }

  function dodge() {
    dodgeCount++;

    // Switch to fixed positioning the first time so it can roam the full viewport
    if (!noBtn.classList.contains('escaping')) {
      const rect = noBtn.getBoundingClientRect();
      noBtn.classList.add('escaping');
      noBtn.style.left = rect.left + 'px';
      noBtn.style.top = rect.top + 'px';
    }

    const { left, top } = getSafeRandomPosition();
    noBtn.style.left = left + 'px';
    noBtn.style.top = top + 'px';

    // Make the "Yes" button grow a little each time, for fun encouragement
    const growth = Math.min(1 + dodgeCount * 0.04, 1.6);
    yesBtn.style.transform = `scale(${growth})`;

    // Occasionally change the No button's text to be extra cute/persuasive
    const teasingTexts = ['No 😭', 'Really? 🥺', 'Are you sure? 😢', 'Nope? 🙈', "Can't catch me! 😝", 'Pick Yes! 💘'];
    if (dodgeCount % 2 === 0) {
      noBtn.textContent = teasingTexts[Math.floor(Math.random() * teasingTexts.length)];
    }
  }

  // Desktop: dodge on hover
  noBtn.addEventListener('mouseenter', dodge);

  // Desktop/mobile: also dodge on click just in case a click ever lands
  noBtn.addEventListener('click', (e) => {
    e.preventDefault();
    dodge();
  });

  // Mobile: dodge on touch before a tap can register as a click
  noBtn.addEventListener('touchstart', (e) => {
    e.preventDefault();
    dodge();
  }, { passive: false });

  // Keep the button inside the viewport if the window is resized
  window.addEventListener('resize', () => {
    if (noBtn.classList.contains('escaping')) {
      const { left, top } = getSafeRandomPosition();
      noBtn.style.left = left + 'px';
      noBtn.style.top = top + 'px';
    }
  });

  // ============================================================
  // 3. "YES" BUTTON — SHOW CELEBRATION SCREEN
  // ============================================================
  function showCelebration() {
    screenOne.classList.add('hidden');
    screenTwo.classList.remove('hidden');

    // Stop spawning new background hearts on screen one (optional cleanup)
    clearInterval(heartInterval);

    launchConfetti();
  }

  yesBtn.addEventListener('click', showCelebration);
  yesBtn.addEventListener('touchend', (e) => {
    e.preventDefault();
    showCelebration();
  }, { passive: false });

  // ============================================================
  // 4. CONFETTI (pure canvas, no libraries)
  // ============================================================
  function launchConfetti() {
    if (!confettiCanvas) return;
    const ctx = confettiCanvas.getContext('2d');
    if (!ctx) return;

    function resizeCanvas() {
      confettiCanvas.width = window.innerWidth;
      confettiCanvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    const colors = ['#ff6b9d', '#ff8fab', '#ffd6e8', '#ffffff', '#ffc7d9', '#4facfe', '#ffe066'];
    const pieceCount = 160;
    const pieces = [];

    for (let i = 0; i < pieceCount; i++) {
      pieces.push({
        x: Math.random() * confettiCanvas.width,
        y: -20 - Math.random() * confettiCanvas.height * 0.5,
        size: 6 + Math.random() * 8,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedY: 2 + Math.random() * 3.5,
        speedX: (Math.random() - 0.5) * 2.5,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 8,
        shape: Math.random() > 0.5 ? 'rect' : 'circle'
      });
    }

    let frame = 0;
    const maxFrames = 420; // roughly 7 seconds at 60fps

    function drawPiece(p) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate((p.rotation * Math.PI) / 180);
      ctx.fillStyle = p.color;
      if (p.shape === 'rect') {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    function animate() {
      frame++;
      ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);

      pieces.forEach((p) => {
        p.y += p.speedY;
        p.x += p.speedX;
        p.rotation += p.rotationSpeed;

        if (p.y > confettiCanvas.height + 20) {
          p.y = -20;
          p.x = Math.random() * confettiCanvas.width;
        }

        drawPiece(p);
      });

      if (frame < maxFrames) {
        requestAnimationFrame(animate);
      } else {
        ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
        window.removeEventListener('resize', resizeCanvas);
      }
    }

    requestAnimationFrame(animate);
  }

});
